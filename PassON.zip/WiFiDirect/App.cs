﻿using Microsoft.Extensions.DependencyInjection;
using Microsoft.MobileBlazorBindings;
using System;
using System.Collections.Generic;
using System.Text;
using WiFiDirect.Features.P2PCommunication;
using WiFiDirect.Contracts;
using Xamarin.Forms;
using WiFiDirect.Features.WiFiP2P;
using Android.Content;
using Android.Net.Wifi.P2p;

namespace WiFiDirect
{
    public class App : Application
    {
        public App(IWifiHandler wifiHandler)
        {
            var host = MobileBlazorBindingsHost.CreateDefaultBuilder()
                       .ConfigureServices((hostContext, services) =>
                       {
                           //Register app-specific services
                           services.AddSingleton<IWifiHandler>(wifiHandler);                                                    
                       })
                       .Build();

            MainPage = new ContentPage();
            host.AddComponent<P2P>(parent: MainPage);
        }

        protected override void OnStart()
        {
        }

        protected override void OnSleep()
        {
        }

        protected override void OnResume()
        {

        }

    }
}
