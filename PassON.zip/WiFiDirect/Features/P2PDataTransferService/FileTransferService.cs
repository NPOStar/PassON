﻿using Android.App;
using Android.Content;
using Android.Widget;
using System;
using System.Collections.Generic;
using System.Text;
using Java.Net;
using System.IO;

namespace WiFiDirect.Features.P2PDataTransferService
{
    public class FileTransferService : IntentService
    {
        private const int SocketTimeout = 5000;
        public static String ActionSendFile = "com.example.android.wifidirect.SEND_FILE";
        public static String ExtrasFilePath = "file_url";
        public static String ExtrasGroupOwnerAddress = "go_host";
        public static String ExtrasGroupOwnerPort = "go_port";

        public FileTransferService()
            : base("FileTransferService")
        {
        }

        public FileTransferService(string name)
            : base(name)
        {
        }
        protected override void OnHandleIntent(Intent intent)
        {
            var context = ApplicationContext;

            if(intent.Action.Equals(ActionSendFile))
            {
                var fileUri = intent.GetStringExtra(ExtrasFilePath);
                var host = intent.GetStringExtra(ExtrasGroupOwnerAddress);
                var port = intent.GetIntExtra(ExtrasGroupOwnerPort, 8988);
                var socket = new Socket();

                try
                {
                    socket.Bind(null);
                    socket.Connect(new InetSocketAddress(host, port), SocketTimeout);

                    var stream = socket.OutputStream;
                    var cr = context.ContentResolver;
                    Stream inputStream = null;
                    
                    try
                    {
                        inputStream = cr.OpenInputStream(Android.Net.Uri.Parse(fileUri));
                    }
                    catch(FileNotFoundException e)
                    {

                    }
                }
                catch(IOException e)
                {

                }
                finally
                {
                    if(socket != null)
                    {
                        if(socket.IsConnected)
                        {
                            try
                            {
                                socket.Close();
                            }
                            catch(IOException e)
                            {

                            }
                        }
                    }
                }
            }
        }

        public static bool CopyFile(Stream inputStream, Stream outputStream)
        {
            var buf = new byte[1024];

            try
            {
                int n;

                while((n = inputStream.Read(buf, 0, buf.Length)) != 0)
                {
                    outputStream.Write(buf, 0, n);
                }
                outputStream.Close();
                inputStream.Close();
            }
            catch(Exception e)
            {
                return false;
            }
            return true;
        }
    }
}
