﻿using Android.OS;
using System.IO;
using Java.Net;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Linq;
using Java.Lang;

namespace WiFiDirect.Features.P2PDataTransferService
{
    public class SendReceiveHandler
    {
        const int MESSAGE_READ = 1;
        static string receivedMsg = string.Empty;
        Socket socket;
        Stream inputStream;
        Stream outputStream;

        public Handler MainHandler { get; set; }    
        
        public static void HandleMessage(Message msg)
        {
            switch (msg.What)
            {
                case MESSAGE_READ:
                    {
                        byte[] readBuff = (byte[])msg.Obj;
                        receivedMsg = Encoding.UTF8.GetString(readBuff);
                        break;
                    }
            }
        }

        public void SendReceiveMessage(Socket skt)
        {
            socket = skt;

            try
            {
                inputStream = socket.InputStream;
                outputStream = socket.OutputStream;
            }
            catch (System.IO.IOException e)
            {

            }
        }

        public void ReadMessage()
        {
            byte[] buffer = new byte[1024];
            int bytes;

            while (socket != null)
            {
                try
                {
                    bytes = inputStream.Read(buffer, 0, buffer.Count());

                    if (bytes > 0)
                    {
                        MainHandler.ObtainMessage(MESSAGE_READ, bytes, -1, buffer).SendToTarget();
                    }
                }
                catch (IOException e)
                {

                }
            }
        }

        public void WriteMessage(byte[] bytes)
        {
            try
            {
                outputStream.Write(bytes, 0, bytes.Count());
            }
            catch(IOException e)
            {

            }            
        }
    }
}
