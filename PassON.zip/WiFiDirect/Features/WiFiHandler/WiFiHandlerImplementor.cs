﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Android.App;
using Android.Content;
using Android.Net;
using Android.Net.Wifi;
using Android.Net.Wifi.P2p;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using WiFiDirect.Contracts;
using WiFiDirect.Features.CustomListeners;
using Xamarin.Essentials;
using Xamarin.Forms.Internals;

namespace WiFiDirect.Features.WiFiHandler
{
    public class WiFiHandlerImplementor : IWifiHandler, IDisposable 
    {
        private bool disposedValue;
        private WifiManager _wifiMgr = null;
        private Context _context = null;
        
        public event Func<Task> OnPeerStatusChange;

        public WiFiHandlerImplementor(WifiManager wifiMgr, WifiP2pManager wifiP2PManager, WifiP2pManager.Channel channel)
        {
            _wifiMgr = wifiMgr;
            WiFiP2PManager = wifiP2PManager;
            WiFiP2PChannel = channel;
            PeerDevices = new List<WifiP2pDevice>();
            PeerDeviceNames = new List<string>();
        }       
        
        public string DeviceType { get; set; }

        public WifiP2pManager WiFiP2PManager { get; set; }
        
        public WifiP2pManager.Channel WiFiP2PChannel { get; set; }

        public bool IsWiFiEnabled
        {
            get
            {
                return _wifiMgr.IsWifiEnabled;
            }
        }

        public Context CurrentApplicationContext { get => _context; set => _context = value; }

        public List<WifiP2pDevice> PeerDevices { get; set; }

        public List<string> PeerDeviceNames { get; set; }

        public WifiP2pDevice[] DeviceArray { get; set; }        

        public bool DisableWiFi()
        {
            return _wifiMgr.SetWifiEnabled(false);
        }

        public bool EnableWiFi()
        {
            return _wifiMgr.SetWifiEnabled(true);
        }

        public WifiState GetWiFiState()
        {
            return _wifiMgr.WifiState;
        }

        public void DiscoverPeers(Action OnFailure, Action OnSucces)
        {
            WiFiP2PManager.DiscoverPeers(WiFiP2PChannel,
                                         new MyActionListener(CurrentApplicationContext,
                                                              OnFailure,
                                                              OnSucces));
        }

        public void RaiseEventOnPeerStatusChange()
        {
            OnPeerStatusChange?.Invoke();
        }

        public void ConnectToPeer(string deviceName, Action onFailureAction, Action onSuccessFailure)
        {
            if(DeviceArray?.Count() > 0)
            {
                WifiP2pDevice device = DeviceArray.Where(x => x.DeviceName == deviceName).FirstOrDefault();

                WifiP2pConfig config = new WifiP2pConfig() { DeviceAddress = device.DeviceAddress,
                                                             Wps = { Setup = WpsInfo.Pbc }
                                                           };                

                WiFiP2PManager.Connect(WiFiP2PChannel,
                                       config,
                                       new MyActionListener(CurrentApplicationContext, onFailureAction, onSuccessFailure));

            }
        }

        protected virtual void Dispose(bool disposing)
        {
            if (!disposedValue)
            {
                if (disposing)
                {
                    // TODO: dispose managed state (managed objects)
                }

                // TODO: free unmanaged resources (unmanaged objects) and override finalizer
                // TODO: set large fields to null
                disposedValue = true;
            }
        }        

        // // TODO: override finalizer only if 'Dispose(bool disposing)' has code to free unmanaged resources
        // ~WiFiHandlerImplementor()
        // {
        //     // Do not change this code. Put cleanup code in 'Dispose(bool disposing)' method
        //     Dispose(disposing: false);
        // }

        public void Dispose()
        {
            // Do not change this code. Put cleanup code in 'Dispose(bool disposing)' method
            Dispose(disposing: true);
            GC.SuppressFinalize(this);
        }
    }
}