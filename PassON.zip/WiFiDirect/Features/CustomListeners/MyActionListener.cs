﻿using Android.Content;
using Android.Net.Wifi.P2p;
using Android.Widget;
using System;
using System.Collections.Generic;
using System.Text;

namespace WiFiDirect.Features.CustomListeners
{
    public class MyActionListener : Java.Lang.Object, WifiP2pManager.IActionListener
    {
        private readonly Context _context;
        private readonly Action _failureAction;
        private readonly Action _successAction;

        public MyActionListener(Context context, Action onFailureAction, Action onSuccessAction)
        {
            _context = context;
            _failureAction = onFailureAction;
            _successAction = onSuccessAction;
        }

        public void OnFailure(WifiP2pFailureReason reason)
        {
            Toast.MakeText(_context, "Discovery Failed: " + reason,
                            ToastLength.Short).Show();
            _failureAction?.Invoke();
        }

        public void OnSuccess()
        {
            Toast.MakeText(_context, "Discovery Initiated",
                            ToastLength.Short).Show();
            _successAction?.Invoke();
        }
    }
}
