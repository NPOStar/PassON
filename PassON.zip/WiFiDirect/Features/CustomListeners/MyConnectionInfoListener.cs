﻿using Android.Net.Wifi.P2p;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using WiFiDirect.Contracts;
using Xamarin.Forms;
using System;
using Java.Net;
using Environment = Android.OS.Environment;
using File = Java.IO.File;
using IOException = Java.IO.IOException;
using WiFiDirect.Features.P2PDataTransferService;
using System.IO;

namespace WiFiDirect.Features.CustomListeners
{
    public class MyConnectionInfoListener : Java.Lang.Object, WifiP2pManager.IConnectionInfoListener
    {
        IWifiHandler _wifiHandler;
        public MyConnectionInfoListener(IWifiHandler wifiHandler)
        {
            _wifiHandler = wifiHandler;
        }        

        public void OnConnectionInfoAvailable(WifiP2pInfo info)
        {
            InetAddress groupOwnerAddress = info.GroupOwnerAddress;

            if(info.GroupFormed && info.IsGroupOwner)
            {
                _wifiHandler.DeviceType = "Host";

                Task.Factory.StartNew(() =>
                {
                    try
                    {
                        var serverSocket = new ServerSocket(8988);
                        var client = serverSocket.Accept();
                        var f = new File(Environment.ExternalStorageDirectory + "/"
                                             + "WiFiDirect" + "/wifip2pshared-" + DateTime.Now.Ticks + ".jpg");
                        var dirs = new File(f.Parent);

                        if(!dirs.Exists())
                        {
                            dirs.Mkdirs();
                        }
                        f.CreateNewFile();

                        var inputStream = client.InputStream;
                        FileTransferService.CopyFile(inputStream, new FileStream(f.ToString(), FileMode.OpenOrCreate));
                        serverSocket.Close();
                        return f.AbsolutePath;
                    }
                    catch(IOException e)
                    {
                        return null;
                    }
                }                
                ).ContinueWith(result => 
                { 
                    if (result != null) 
                    { 
                    } 
                });
            }
            else if (info.GroupFormed)
            {
                _wifiHandler.DeviceType = "Client";
            }            
        }
    }
}
