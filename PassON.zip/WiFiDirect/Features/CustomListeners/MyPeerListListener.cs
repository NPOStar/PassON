﻿using Android.Net.Wifi.P2p;
using Android.Widget;
using Microsoft.AspNetCore.Components;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using WiFiDirect.Contracts;

namespace WiFiDirect.Features.CustomListeners
{
    public class MyPeerListListener : Java.Lang.Object, WifiP2pManager.IPeerListListener
    {
        private IWifiHandler WifiHandler;

        public MyPeerListListener(IWifiHandler wifiHandler)
        {
            WifiHandler = wifiHandler;
        } 

        public void OnPeersAvailable(WifiP2pDeviceList p2PDeviceList)
        {
            if(p2PDeviceList.DeviceList != null && 
               p2PDeviceList.DeviceList.Count > 0 &&
               !p2PDeviceList.DeviceList.Equals(WifiHandler.PeerDevices))
            {
                WifiHandler.PeerDevices.Clear();
                WifiHandler.PeerDevices.AddRange(p2PDeviceList.DeviceList);                
                WifiHandler.DeviceArray = new WifiP2pDevice[p2PDeviceList.DeviceList.Count];

                int index = 0;

                foreach(WifiP2pDevice device in p2PDeviceList.DeviceList)
                {
                    WifiHandler.PeerDeviceNames.Add(device.DeviceName);
                    WifiHandler.DeviceArray[index] = device;
                    index++;
                }

                WifiHandler.RaiseEventOnPeerStatusChange();
            }

            if(p2PDeviceList.DeviceList.Count == 0)
            {
                Toast.MakeText(WifiHandler.CurrentApplicationContext, "No Device Found", ToastLength.Short).Show();
            }
        }
    }
}
