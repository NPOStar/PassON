﻿using Android.Content;
using Android.Net;
using Android.Net.Wifi;
using Android.Net.Wifi.P2p;
using Android.Runtime;
using Microsoft.AspNetCore.Components;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WiFiDirect.Contracts;
using Xamarin.Essentials;
using Xamarin.Forms;

namespace WiFiDirect.Features.P2PCommunication
{
    public partial class P2P : IDisposable
    {
        const string WIFION = "WiFi ON";
        const string WIFIOFF = "WiFi OFF";
        string _wifiStatusText = WIFIOFF;
        string _discoveryStatus = string.Empty;
        string _receivedMsg = "...waiting for new message";
        string selectedDevice = string.Empty;
        AppTheme theme;
        IWifiHandler _wifiHandler = null;        

        [Inject]
        public IWifiHandler WiFiHandler
        {
            get
            {
                return _wifiHandler;
            }
            set
            {
                _wifiHandler = value;

                if(_wifiHandler != null && _wifiHandler.IsWiFiEnabled)
                {
                    _wifiStatusText = WIFIOFF;
                    _wifiHandler.OnPeerStatusChange += UpdateStatus;
                }
            }
        }       

        public void Dispose() => _wifiHandler.OnPeerStatusChange -= UpdateStatus;

        private void ChangeWiFiState()
        {
            if(WiFiHandler.GetWiFiState() == WifiState.Enabled)
            {
                WiFiHandler.DisableWiFi();
                _wifiStatusText = WIFION;
            }
            else
            {
                WiFiHandler.EnableWiFi();
                _wifiStatusText = WIFIOFF;
            }
        }

        private void DiscoverPeers()
        {            
            WiFiHandler.DiscoverPeers(() => { _discoveryStatus = "Discovery failed"; StateHasChanged(); },
                                      () => { _discoveryStatus = "Discovery started"; StateHasChanged(); });

            // test code need to remove
            WiFiHandler.PeerDeviceNames.AddRange(new string[] { "M1", "M2", "M3" });            
        }

        private void ConnectToPeer()
        {
            // test code need to remove
            selectedDevice = WiFiHandler.PeerDeviceNames.FirstOrDefault();
            WiFiHandler.ConnectToPeer(selectedDevice,
                                      () => { _discoveryStatus = "Failed to connect."; StateHasChanged(); },
                                      () => { _discoveryStatus = "Connected to " + selectedDevice; StateHasChanged(); });
            
        }

        private void ConnectToPeer(string deviceName)
        {
            //string devicename = "Android SDK built for x86";
            WiFiHandler.ConnectToPeer(deviceName,
                                      () => { _discoveryStatus = "Failed to connect."; StateHasChanged(); },
                                      () => { _discoveryStatus = "Connected to " + deviceName; StateHasChanged(); });

        }

        protected async Task UpdateStatus()
        {            
            await new Task(() => { });
            StateHasChanged();
        }

        private void SendMessage()
        {

        }
    }
}
