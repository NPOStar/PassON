﻿using Android.Content;
using Android.Net;
using Android.Net.Wifi.P2p;
using Android.Widget;
using System;
using System.Collections.Generic;
using System.Text;
using WiFiDirect.Features.CustomListeners;

namespace WiFiDirect.Features.WiFiP2P
{
    public class WiFiDirectBroadcastReceiver : BroadcastReceiver
    {
        private WifiP2pManager _wifiP2pManager;
        private WifiP2pManager.Channel _channel;
        private MyPeerListListener _myPeerListListener;
        private MyConnectionInfoListener _myConnectionInfoListener;        

        public WiFiDirectBroadcastReceiver(WifiP2pManager wifiP2pManager, 
                                           WifiP2pManager.Channel channel,
                                           MyPeerListListener myPeerListListener,
                                           MyConnectionInfoListener myConnectionInfoListener)
        {
            _wifiP2pManager = wifiP2pManager;
            _channel = channel;
            _myPeerListListener = myPeerListListener;
            _myConnectionInfoListener = myConnectionInfoListener;
        }

        public override void OnReceive(Context context, Intent intent)
        {
            string action = intent.Action;

            switch (action)
            {
                case WifiP2pManager.WifiP2pStateChangedAction:
                    {
                        //check to see if WiFi is enabled and notify appropriate activity
                        int state = intent.GetIntExtra(WifiP2pManager.ExtraWifiState, -1);

                        if(state == Convert.ToInt32(WifiP2pState.Enabled))
                        {
                            Toast.MakeText(context, "WiFi is ON", ToastLength.Short).Show();
                        }
                        else
                        {
                            Toast.MakeText(context, "WiFi is OFF", ToastLength.Short).Show();
                        }                       

                        break;
                    }
                case WifiP2pManager.WifiP2pPeersChangedAction:
                    {
                        //Call WifiP2pManager to get an list of current peers
                        _wifiP2pManager.RequestPeers(_channel, _myPeerListListener);
                        break;
                    }
                case WifiP2pManager.WifiP2pConnectionChangedAction:
                    {
                        //respond to new connection or disconnections
                        if (_wifiP2pManager == null)
                        {
                            return;
                        }                      

                        NetworkInfo networkInfo = (NetworkInfo)intent.GetParcelableExtra(WifiP2pManager.ExtraNetworkInfo);
                        
                        if(networkInfo.IsConnected)
                        {
                            _wifiP2pManager.RequestConnectionInfo(_channel, _myConnectionInfoListener);
                        }
                        else
                        {
                            Toast.MakeText(context, "Not connected", ToastLength.Short).Show();
                        }
                        break;
                    }
                case WifiP2pManager.WifiP2pThisDeviceChangedAction:
                    {
                        // respong to this device's WiFi state changing
                        break;
                    }
            }

        }
    }
}
