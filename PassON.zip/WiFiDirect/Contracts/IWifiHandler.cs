﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Android.App;
using Android.Content;
using Android.Net;
using Android.Net.Wifi.P2p;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;

namespace WiFiDirect.Contracts
{
    public interface IWifiHandler
    {
        string DeviceType { get; set; }

        WifiP2pManager WiFiP2PManager { get; set; }

        WifiP2pManager.Channel WiFiP2PChannel { get; set; }

        Context CurrentApplicationContext { get; set; }

        event Func<Task> OnPeerStatusChange;

        bool IsWiFiEnabled { get; }

        List<WifiP2pDevice> PeerDevices { get; set; }

        List<string> PeerDeviceNames { get; set; }

        WifiP2pDevice[] DeviceArray { get; set; }

        WifiState GetWiFiState();

        bool EnableWiFi();

        bool DisableWiFi();

        void DiscoverPeers(Action OnFailure, Action OnSucces);

        void RaiseEventOnPeerStatusChange();

        void ConnectToPeer(string deviceName, Action onFailureAction, Action onSuccessFailure);        
    }
}