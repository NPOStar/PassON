﻿using System;
using Android.App;
using Android.Content.PM;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.OS;
using Microsoft.MobileBlazorBindings.WebView.Android;
using Android.Content;
using Android.Net.Wifi;
using WiFiDirect.Features.WiFiHandler;
using WiFiDirect.Features.WiFiP2P;
using Android.Net.Wifi.P2p;
using WiFiDirect.Contracts;
using WiFiDirect.Features.CustomListeners;
using SQLitePCL;
using WiFiDirect.Features.P2PDataTransferService;

namespace PassON.Droid
{
    [Activity(Label = "PassON", Icon = "@mipmap/icon", Theme = "@style/MainTheme", MainLauncher = true, ConfigurationChanges = ConfigChanges.ScreenSize | ConfigChanges.Orientation)]
    public class MainActivity : global::Xamarin.Forms.Platform.Android.FormsAppCompatActivity
    {        
        WifiManager wifiMgr = null;
        IWifiHandler wifiHandler = null;

        //WifiP2p
        WifiP2pManager wifiP2pMgr = null;
        WifiP2pManager.Channel channel = null;
        WiFiDirectBroadcastReceiver wifiBroadcastReceiver = null;
        IntentFilter intentFilter = null;
        MyPeerListListener customPeerListListener = null;
        MyConnectionInfoListener customConnectionInfoListener = null;
        Handler handler = null;
        protected override void OnCreate(Bundle savedInstanceState)
        {
            BlazorHybridAndroid.Init();

            TabLayoutResource = Resource.Layout.Tabbar;
            ToolbarResource = Resource.Layout.Toolbar;

            base.OnCreate(savedInstanceState);

            Xamarin.Essentials.Platform.Init(this, savedInstanceState);
            global::Xamarin.Forms.Forms.Init(this, savedInstanceState);
            InitializeDependencies();
            LoadApplication(new WiFiDirect.App(wifiHandler));
        }

        private void InitializeDependencies()
        {
            //Wifi
            wifiMgr = this.ApplicationContext.GetSystemService(Context.WifiService).JavaCast<WifiManager>();

            //WifiP2p
            wifiP2pMgr = this.ApplicationContext.GetSystemService(Context.WifiP2pService).JavaCast<WifiP2pManager>();
            channel = wifiP2pMgr.Initialize(this.ApplicationContext, MainLooper, null);

            //wifiHandler
            wifiHandler = new WiFiHandlerImplementor(wifiMgr, wifiP2pMgr, channel);
            wifiHandler.CurrentApplicationContext = this.ApplicationContext;

            customPeerListListener = new MyPeerListListener(wifiHandler);
            customConnectionInfoListener = new MyConnectionInfoListener(wifiHandler);
            wifiBroadcastReceiver = new WiFiDirectBroadcastReceiver(wifiP2pMgr,
                                                                    channel,
                                                                    customPeerListListener,
                                                                    customConnectionInfoListener);

            intentFilter = new IntentFilter();
            intentFilter.AddAction(WifiP2pManager.WifiP2pStateChangedAction);
            intentFilter.AddAction(WifiP2pManager.WifiP2pPeersChangedAction);
            intentFilter.AddAction(WifiP2pManager.WifiP2pConnectionChangedAction);
            intentFilter.AddAction(WifiP2pManager.WifiP2pThisDeviceChangedAction);
            
            //ToDO to send receive messages
            //handler = new Handler(new Action<Message>(SendReceiveHandler.HandleMessage));
            //SendReceiveHandler sendReceiveHandler = new SendReceiveHandler();
            //sendReceiveHandler.MainHandler = handler;
        }

        protected override void OnResume()
        {
            base.OnResume();
            RegisterReceiver(wifiBroadcastReceiver, intentFilter);
        }

        protected override void OnPause()
        {
            base.OnPause();
            UnregisterReceiver(wifiBroadcastReceiver);
        }

        public override void OnRequestPermissionsResult(int requestCode, string[] permissions, [GeneratedEnum] Android.Content.PM.Permission[] grantResults)
        {
            Xamarin.Essentials.Platform.OnRequestPermissionsResult(requestCode, permissions, grantResults);

            base.OnRequestPermissionsResult(requestCode, permissions, grantResults);
        }
    }
}
